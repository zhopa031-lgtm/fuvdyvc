import type { Metadata } from "next";
import { Unbounded, Manrope } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const displayFont = Unbounded({
  variable: "--font-display-var",
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800"],
});

const bodyFont = Manrope({
  variable: "--font-body-var",
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "НовыйДом — строительство домов в Минске и Беларуси под ключ",
  description:
    "Строим каркасные дома, дома из газобетона и кирпича в Минске и по всей Беларуси. Каталог проектов от 68 900 $, гарантия 10 лет, фикс-смета в договоре. Средние цены рынка 2025 года.",
  keywords: [
    "строительство домов Минск",
    "каркасные дома Беларусь",
    "дома из газобетона",
    "строительство под ключ Минск",
    "каталог проектов домов",
  ],
  openGraph: {
    title: "НовыйДом — строительство домов в Минске",
    description:
      "Каталог проектов домов, реальные цены рынка Беларуси 2025, гарантия 10 лет.",
    siteName: "НовыйДом",
    type: "website",
    locale: "ru_BY",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${displayFont.variable} ${bodyFont.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
