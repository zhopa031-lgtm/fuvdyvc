"use client";

import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Toaster } from "sonner";

import SmoothScroll from "@/components/site/smooth-scroll";
import Preloader from "@/components/site/preloader";
import Cursor from "@/components/site/cursor";
import ScrollProgress from "@/components/site/scroll-progress";
import Navbar from "@/components/site/navbar";
import Hero from "@/components/site/hero";
import Marquee from "@/components/site/marquee";
import Stats from "@/components/site/stats";
import Catalog from "@/components/site/catalog";
import HouseModal from "@/components/site/house-modal";
import Prices from "@/components/site/prices";
import Process from "@/components/site/process";
import Gallery from "@/components/site/gallery";
import About from "@/components/site/about";
import Contact from "@/components/site/contact";
import Footer from "@/components/site/footer";

import { HOUSES, type House } from "@/lib/houses";

export default function Page() {
  const [loaded, setLoaded] = useState(false);
  const [filter, setFilter] = useState<"all" | House["tech"]>("all");
  const [selectedHouse, setSelectedHouse] = useState<House | null>(null);

  return (
    <div className="grain relative min-h-screen flex flex-col bg-stone-950">
      <Toaster position="bottom-right" theme="dark" richColors />

      {/* Плавный скролл */}
      <SmoothScroll />
      <ScrollProgress />
      <Cursor />

      {/* Прелоадер */}
      <AnimatePresence>
        {!loaded && <Preloader onFinish={() => setLoaded(true)} />}
      </AnimatePresence>

      <Navbar loaded={loaded} />

      <main className="flex-1">
        <Hero loaded={loaded} />
        <Marquee />
        <Stats />
        <Catalog
          houses={HOUSES}
          selected={filter}
          onSelect={setFilter}
          onOpen={setSelectedHouse}
        />
        <Prices />
        <Process />
        <Gallery />
        <About />
        <Contact />
      </main>

      <Footer />

      <HouseModal house={selectedHouse} onClose={() => setSelectedHouse(null)} />
    </div>
  );
}
