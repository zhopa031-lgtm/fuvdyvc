"use client";

import { useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export function Magnetic({ children, strength = 0.35 }: { children: React.ReactNode; strength?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 180, damping: 14, mass: 0.4 });
  const y = useSpring(my, { stiffness: 180, damping: 14, mass: 0.4 });

  const onMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set((e.clientX - (r.left + r.width / 2)) * strength);
    my.set((e.clientY - (r.top + r.height / 2)) * strength);
  };
  const onLeave = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <motion.div
      ref={ref}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className="inline-block"
    >
      {children}
    </motion.div>
  );
}

export function MagneticButton({
  children,
  onClick,
  variant = "primary",
  className = "",
  href,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost";
  className?: string;
  href?: string;
}) {
  const inner = (
    <motion.span
      whileTap={{ scale: 0.96 }}
      className={`inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 font-semibold text-sm md:text-base transition-colors ${
        variant === "primary"
          ? "bg-amber-500 text-stone-950 hover:bg-amber-400 shadow-[0_0_30px_rgba(245,158,11,0.35)]"
          : "border border-stone-600 text-stone-200 hover:border-amber-500 hover:text-amber-400"
      } ${className}`}
    >
      {children}
    </motion.span>
  );

  return (
    <Magnetic>
      {href ? (
        <a href={href} target="_blank" rel="noreferrer" onClick={onClick} data-cursor="hover">
          {inner}
        </a>
      ) : (
        <button onClick={onClick} data-cursor="hover">
          {inner}
        </button>
      )}
    </Magnetic>
  );
}
