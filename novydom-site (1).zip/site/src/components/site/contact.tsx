"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { RevealTitle, FadeIn } from "./reveal";
import { MagneticButton } from "./magnetic";
import { toast } from "sonner";
import {
  PHONE_DISPLAY,
  PHONE_TEL,
  INSTAGRAM_URL,
  INSTAGRAM_HANDLE,
  ADDRESS,
} from "@/lib/houses";
import { Phone, MapPin, Clock3, Send, Camera } from "lucide-react";

export default function Contact() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [msg, setMsg] = useState("");
  const [sending, setSending] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("Заполните имя и телефон — мы перезвоним в течение 15 минут");
      return;
    }
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setName("");
      setPhone("");
      setMsg("");
      toast.success(`${name}, заявка принята! Перезвоним в течение 15 минут.`);
    }, 1200);
  };

  return (
    <section id="contacts" ref={ref} className="relative overflow-hidden py-24 md:py-32">
      {/* Параллакс-фон */}
      <motion.div className="absolute inset-[-14%] z-0" style={{ y: bgY }}>
        <Image
          src="/images/cta-wide.jpg"
          alt="Современный дом в вечернем освещении"
          fill
          sizes="100vw"
          className="object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-stone-950 via-stone-950/70 to-stone-950" />
      </motion.div>

      <div className="relative z-10 mx-auto grid max-w-7xl gap-14 px-4 lg:grid-cols-[1.1fr_0.9fr]">
        {/* Левая часть: контакты */}
        <div>
          <FadeIn>
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-4 py-1.5 text-[11px] md:text-xs font-semibold uppercase tracking-[0.25em] text-amber-400">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse-glow" />
              Контакты
            </span>
          </FadeIn>
          <RevealTitle
            text="Обсудим ваш будущий дом?"
            className="mt-5 font-display text-3xl md:text-5xl font-bold text-stone-50"
          />
          <FadeIn delay={0.1}>
            <p className="mt-5 max-w-lg text-sm md:text-base text-stone-400">
              Позвоните или напишите — ответим на все вопросы о ценах, проектах
              и сроках. Консультация на вашем участке — бесплатно в радиусе 100 км
              от Минска.
            </p>
          </FadeIn>

          {/* Телефон — крупно */}
          <motion.a
            href={`tel:${PHONE_TEL}`}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            whileHover={{ scale: 1.03 }}
            className="mt-9 flex items-center gap-4"
          >
            <span className="relative flex h-13 w-13 items-center justify-center rounded-2xl bg-amber-500/15 text-amber-500 md:h-14 md:w-14">
              <span className="absolute inset-0 animate-ping rounded-2xl bg-amber-500/20" />
              <Phone className="relative h-6 w-6" />
            </span>
            <span>
              <span className="block text-xs uppercase tracking-[0.2em] text-stone-500">
                Звоните нам
              </span>
              <span className="font-display text-2xl md:text-4xl font-extrabold text-stone-50 transition-colors hover:text-amber-400">
                {PHONE_DISPLAY}
              </span>
            </span>
          </motion.a>

          {/* Instagram */}
          <motion.a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noreferrer"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.25 }}
            whileHover={{ scale: 1.02, x: 6 }}
            className="mt-6 flex items-center gap-4 rounded-3xl border border-stone-800 bg-card/60 p-5 backdrop-blur transition-colors hover:border-amber-500/50"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 text-white">
              <Camera className="h-6 w-6" />
            </span>
            <span>
              <span className="block text-xs uppercase tracking-[0.2em] text-stone-500">
                Instagram · фото наших строек
              </span>
              <span className="mt-0.5 block font-display text-lg md:text-2xl font-bold text-stone-50">
                {INSTAGRAM_HANDLE}
              </span>
            </span>
            <Send className="ml-auto h-5 w-5 text-stone-600 transition-transform group-hover:translate-x-1" />
          </motion.a>

          {/* Адрес и часы */}
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="rounded-3xl border border-stone-800 bg-card/60 p-5 backdrop-blur"
            >
              <MapPin className="h-5 w-5 text-amber-500" />
              <div className="mt-2.5 text-xs uppercase tracking-[0.18em] text-stone-500">
                Офис в Минске
              </div>
              <div className="mt-1 text-sm md:text-base font-semibold text-stone-100">
                {ADDRESS}
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.38 }}
              className="rounded-3xl border border-stone-800 bg-card/60 p-5 backdrop-blur"
            >
              <Clock3 className="h-5 w-5 text-amber-500" />
              <div className="mt-2.5 text-xs uppercase tracking-[0.18em] text-stone-500">
                Режим работы
              </div>
              <div className="mt-1 text-sm md:text-base font-semibold text-stone-100">
                Пн–Сб: 9:00–19:00
              </div>
            </motion.div>
          </div>
        </div>

        {/* Правая часть: форма */}
        <FadeIn delay={0.2} className="relative">
          <motion.form
            onSubmit={submit}
            whileHover={{ y: -4 }}
            className="rounded-3xl border border-stone-800 bg-card/80 p-6 md:p-8 backdrop-blur-xl shadow-[0_30px_80px_rgba(0,0,0,0.5)]"
          >
            <h3 className="font-display text-xl md:text-2xl font-bold text-stone-50">
              Заявка на консультацию
            </h3>
            <p className="mt-2 text-sm text-stone-400">
              Оставьте номер — перезвоним в течение 15 минут в рабочее время.
            </p>

            <div className="mt-6 space-y-4">
              <div>
                <label htmlFor="c-name" className="mb-1.5 block text-xs uppercase tracking-[0.18em] text-stone-500">
                  Ваше имя
                </label>
                <input
                  id="c-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Александр"
                  className="w-full rounded-2xl border border-stone-700 bg-stone-900/70 px-4.5 py-3.5 text-sm text-stone-100 placeholder:text-stone-600 outline-none transition-all focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25"
                />
              </div>
              <div>
                <label htmlFor="c-phone" className="mb-1.5 block text-xs uppercase tracking-[0.18em] text-stone-500">
                  Телефон
                </label>
                <input
                  id="c-phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+375 (__) ___-__-__"
                  type="tel"
                  className="w-full rounded-2xl border border-stone-700 bg-stone-900/70 px-4.5 py-3.5 text-sm text-stone-100 placeholder:text-stone-600 outline-none transition-all focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25"
                />
              </div>
              <div>
                <label htmlFor="c-msg" className="mb-1.5 block text-xs uppercase tracking-[0.18em] text-stone-500">
                  Какой дом интересует? <span className="normal-case text-stone-600">(необязательно)</span>
                </label>
                <textarea
                  id="c-msg"
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  placeholder="Например: каркасный дом около 120 м² под Минском…"
                  rows={3}
                  className="w-full resize-none rounded-2xl border border-stone-700 bg-stone-900/70 px-4.5 py-3.5 text-sm text-stone-100 placeholder:text-stone-600 outline-none transition-all focus:border-amber-500 focus:ring-2 focus:ring-amber-500/25"
                />
              </div>
            </div>

            <MagneticButton className="mt-7 w-full">
              <span className={sending ? "opacity-60" : ""}>
                {sending ? "Отправляем…" : "Получить консультацию"}
              </span>
            </MagneticButton>

            <p className="mt-4 text-center text-[11px] leading-relaxed text-stone-600">
              Нажимая кнопку, вы соглашаетесь с обработкой персональных данных.
              Никакого спама — только один звонок инженера.
            </p>
          </motion.form>
        </FadeIn>
      </div>
    </section>
  );
}
