"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import { SectionBadge } from "./reveal";

const PHOTOS = [
  { src: "/images/build1.jpg", cap: "Монтаж каркаса", tag: "Технология" },
  { src: "/images/int2.jpg", cap: "Гостиная под ключ", tag: "Интерьер" },
  { src: "/images/build3.jpg", cap: "Стены из газобетона", tag: "Конструктив" },
  { src: "/images/int3.jpg", cap: "Кухня-гостиная", tag: "Интерьер" },
  { src: "/images/build6.jpg", cap: "Кровельные работы", tag: "Конструктив" },
  { src: "/images/int5.jpg", cap: "Спальня в мансарде", tag: "Интерьер" },
  { src: "/images/build2.jpg", cap: "Работа бригады", tag: "Процесс" },
  { src: "/images/int6.jpg", cap: "Чистовая отделка", tag: "Интерьер" },
  { src: "/images/build5.jpg", cap: "Фасад и утепление", tag: "Фасады" },
  { src: "/images/int4.jpg", cap: "Санузел под ключ", tag: "Интерьер" },
  { src: "/images/build7.jpg", cap: "Объект под Минском", tag: "Процесс" },
  { src: "/images/int1.jpg", cap: "Дом вашей мечты", tag: "Результат" },
];

export default function Gallery() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref });
  const x = useTransform(scrollYProgress, [0, 1], ["2%", "-76%"]);

  return (
    <section ref={ref} className="relative h-[340vh]">
      <div className="sticky top-0 flex h-screen flex-col justify-center overflow-hidden">
        <div className="mx-auto w-full max-w-7xl px-4 pb-8">
          <SectionBadge>Наши работы</SectionBadge>
          <h2 className="mt-4 font-display text-3xl md:text-5xl font-bold text-stone-50">
            Смотрите, как рождаются <span className="text-amber-500">дома</span>
          </h2>
          <p className="mt-3 max-w-xl text-sm md:text-base text-stone-400">
            Реальные объекты: от монтажа каркаса до чистовой отделки. Скролльте вниз —
            галерея движется вбок.
          </p>
        </div>

        <motion.div style={{ x }} className="flex gap-6 pl-4 md:pl-[max(1rem,calc((100vw-80rem)/2+1rem))]">
          {PHOTOS.map((p, i) => (
            <motion.div
              key={p.src + i}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-40px" }}
              transition={{ duration: 0.7, delay: (i % 4) * 0.08 }}
              className={`group relative shrink-0 overflow-hidden rounded-3xl border border-stone-800 ${
                i % 3 === 1
                  ? "h-[58vh] w-[78vw] md:h-[62vh] md:w-[42vw]"
                  : "h-[52vh] w-[68vw] md:h-[56vh] md:w-[34vw]"
              }`}
              data-cursor="hover"
            >
              <Image
                src={p.src}
                alt={`Фото строительства и отделки: ${p.cap}`}
                fill
                sizes="(max-width: 768px) 80vw, 42vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/85 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className="rounded-full bg-amber-500/90 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-stone-950">
                  {p.tag}
                </span>
                <div className="mt-2 font-display text-base md:text-xl font-bold text-stone-50">
                  {p.cap}
                </div>
              </div>
            </motion.div>
          ))}
          {/* Финальная карточка */}
          <div className="flex h-[52vh] w-[68vw] shrink-0 flex-col items-center justify-center rounded-3xl border border-amber-500/40 bg-amber-500/10 md:h-[56vh] md:w-[30vw]">
            <span className="font-display text-4xl md:text-5xl font-extrabold text-amber-500">
              327+
            </span>
            <span className="mt-3 max-w-[220px] text-center text-sm text-stone-300">
              готовых домов в Минске и по Беларуси
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
