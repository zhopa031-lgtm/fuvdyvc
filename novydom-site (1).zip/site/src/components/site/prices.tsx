"use client";

import { motion } from "framer-motion";
import { MARKET_PRICES, EXTRA_COSTS } from "@/lib/houses";
import { RevealTitle, SectionBadge, FadeIn } from "./reveal";
import { TrendingUp, MapPin, FileText, Home } from "lucide-react";

export default function Prices() {
  return (
    <section id="prices" className="relative py-24 md:py-32 overflow-hidden">
      {/* фоновая подложка */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent" />
      <div className="pointer-events-none absolute right-[-12%] top-[8%] h-[420px] w-[420px] rounded-full bg-amber-500/7 blur-[140px]" />

      <div className="mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-3xl text-center">
          <div className="flex justify-center">
            <SectionBadge>Средние цены · Беларусь 2025</SectionBadge>
          </div>
          <RevealTitle
            text="Сколько стоит построить дом?"
            className="mt-5 font-display text-3xl md:text-5xl font-bold text-stone-50"
          />
          <FadeIn delay={0.1}>
            <p className="mt-5 text-sm md:text-base text-stone-400">
              Мы проанализировали актуальные предложения белорусских застройщиков
              (stroi.by, 1house.by, karkasservice.by, karkasnyi-dom.by, domovita.by)
              и собрали реальные рыночные цифры — без маркетинговых «цен от».
            </p>
          </FadeIn>
        </div>

        {/* Основные цены за м² */}
        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {MARKET_PRICES.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 40, rotateX: -8 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -8 }}
              className={`group relative overflow-hidden rounded-3xl border p-6 md:p-7 ${
                p.accent
                  ? "border-amber-500/60 bg-gradient-to-b from-amber-500/15 to-card shadow-[0_20px_60px_rgba(245,158,11,0.15)]"
                  : "border-stone-800 bg-card/70"
              }`}
            >
              <div className="absolute inset-x-0 top-0 h-[2px] overflow-hidden">
                <div className="animate-shimmer h-full w-1/3 bg-gradient-to-r from-transparent via-amber-400/70 to-transparent" />
              </div>
              <Home className={`h-6 w-6 ${p.accent ? "text-amber-500" : "text-stone-500"}`} />
              <h3 className="mt-4 font-display text-base md:text-lg font-bold text-stone-100">
                {p.title}
              </h3>
              <div
                className={`mt-3 font-display text-xl md:text-2xl font-extrabold ${
                  p.accent ? "text-amber-500" : "text-stone-50"
                }`}
              >
                {p.range}
              </div>
              <p className="mt-3 text-xs md:text-sm leading-relaxed text-stone-400">
                {p.note}
              </p>
              {p.accent && (
                <span className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1 text-[11px] font-semibold text-amber-400">
                  <TrendingUp className="h-3 w-3" /> Самый популярный формат в РБ
                </span>
              )}
            </motion.div>
          ))}
        </div>

        {/* Дополнительные расходы */}
        <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-3">
          {EXTRA_COSTS.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, x: i === 0 ? -30 : i === 1 ? 0 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.12 }}
              className="flex items-start gap-4 rounded-3xl border border-stone-800 bg-card/50 p-6"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-amber-500/12 text-amber-500">
                {i === 0 ? <FileText className="h-5 w-5" /> : <MapPin className="h-5 w-5" />}
              </span>
              <div>
                <div className="text-xs uppercase tracking-[0.18em] text-stone-500">
                  {c.title}
                </div>
                <div className="mt-1.5 font-display text-lg md:text-xl font-bold text-amber-500">
                  {c.value}
                </div>
                <div className="mt-1.5 text-xs md:text-sm text-stone-400">{c.note}</div>
              </div>
            </motion.div>
          ))}
        </div>

        <FadeIn delay={0.15} className="mt-10 text-center">
          <p className="mx-auto max-w-2xl rounded-2xl border border-stone-800 bg-card/40 px-6 py-4 text-xs md:text-sm text-stone-500">
            Все цены в каталоге — «под ключ»: фундамент, коробка, кровля, инженерные
            сети и отделка. Стоимость участка и проекта считается отдельно и зависит
            от локации. Итоговая смета фиксируется в договоре и не меняется.
          </p>
        </FadeIn>
      </div>
    </section>
  );
}
