"use client";

import { useEffect, useRef, useState } from "react";
import { animate, useInView } from "framer-motion";
import { FadeIn } from "./reveal";

function Counter({
  to,
  suffix = "",
  prefix = "",
  duration = 2.2,
}: {
  to: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, to, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setVal(v),
    });
    return () => controls.stop();
  }, [inView, to, duration]);

  return (
    <span className="tabular-nums">
      {prefix}
      {Math.round(val)}
      {suffix}
    </span>
  );
}

const STATS = [
  { value: 14, suffix: "", label: "лет строим в Беларуси", note: "на рынке с 2011 года" },
  { value: 327, suffix: "", label: "домов построено", note: "Минск и вся РБ" },
  { value: 98, suffix: "%", label: "клиентов рекомендуют", note: "по опросу 2025 года" },
  { value: 10, suffix: "", label: "лет гарантии", note: "на конструктив и работы" },
];

export default function Stats() {
  return (
    <section className="relative py-20 md:py-28">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-x-6 gap-y-12 px-4 md:grid-cols-4">
        {STATS.map((s, i) => (
          <FadeIn key={s.label} delay={i * 0.12} className="text-center">
            <div className="font-display text-5xl md:text-7xl font-extrabold text-amber-500">
              <Counter to={s.value} suffix={s.suffix} />
            </div>
            <div className="mt-3 text-sm md:text-base font-semibold text-stone-100">
              {s.label}
            </div>
            <div className="mt-1 text-xs md:text-sm text-stone-500">{s.note}</div>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}
