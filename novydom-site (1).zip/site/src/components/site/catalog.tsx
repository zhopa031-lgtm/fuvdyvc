"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { TECH_LABEL, type House } from "@/lib/houses";
import { MagneticButton } from "./magnetic";
import { scrollToId } from "./smooth-scroll";
import { BedDouble, Bath, Ruler, Clock3, Sparkles } from "lucide-react";

function TiltCard({
  house,
  index,
  onOpen,
}: {
  house: House;
  index: number;
  onOpen: (h: House) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const rmx = useMotionValue(0);
  const rmy = useMotionValue(0);
  const rotateX = useSpring(rmy, { stiffness: 200, damping: 22 });
  const rotateY = useSpring(rmx, { stiffness: 200, damping: 22 });
  const [hover, setHover] = useState(false);

  const onMouseMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    rmx.set(px * 10);
    rmy.set(-py * 10);
  };
  const onLeave = () => {
    rmx.set(0);
    rmy.set(0);
    setHover(false);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9, y: 30 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: 20 }}
      transition={{ duration: 0.55, delay: index * 0.06, ease: [0.22, 1, 0.36, 1] }}
      style={{ perspective: 1200 }}
    >
      <motion.div
        ref={ref}
        onMouseMove={onMouseMove}
        onMouseLeave={onLeave}
        onMouseEnter={() => setHover(true)}
        onClick={() => onOpen(house)}
        data-cursor="hover"
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        className="group relative overflow-hidden rounded-3xl border border-stone-800 bg-card shadow-2xl will-change-transform"
        whileHover={{ boxShadow: "0 30px 70px rgba(245,158,11,0.16)" }}
      >
        {/* Фото */}
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image
            src={house.image}
            alt={`Проект дома ${house.name} — ${house.area} м², Минск`}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/85 via-transparent to-stone-950/20" />

          {/* Технология */}
          <span className="absolute left-4 top-4 rounded-full bg-stone-950/70 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-amber-400 backdrop-blur-md border border-amber-500/30">
            {TECH_LABEL[house.tech]}
          </span>

          {/* Премиум */}
          {house.priceFrom >= 200000 && (
            <span className="absolute right-4 top-4 flex items-center gap-1.5 rounded-full bg-amber-500 px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-stone-950">
              <Sparkles className="h-3.5 w-3.5" /> Премиум
            </span>
          )}

          {/* Цена — главная часть требования заказчика */}
          <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between" style={{ transform: "translateZ(40px)" }}>
            <div>
              <div className="text-[11px] uppercase tracking-[0.25em] text-stone-400">
                цена под ключ
              </div>
              <div className="font-display text-2xl md:text-[26px] font-bold text-amber-500">
                от {house.priceFrom.toLocaleString("ru-RU")} $
              </div>
            </div>
            <span className="rounded-full border border-stone-100/25 bg-stone-100/10 px-3 py-1.5 text-xs font-semibold text-stone-100 backdrop-blur-md opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              Подробнее →
            </span>
          </div>
        </div>

        {/* Инфо */}
        <div className="p-5 md:p-6">
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="font-display text-lg md:text-xl font-bold text-stone-50">
              {house.name}
            </h3>
            <span className="text-xs text-stone-500">{house.district}</span>
          </div>
          <p className="mt-2 line-clamp-2 text-sm text-stone-400">{house.tagline}</p>
          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-stone-300">
            <span className="flex items-center gap-1.5">
              <Ruler className="h-4 w-4 text-amber-500" /> {house.area} м²
            </span>
            <span className="flex items-center gap-1.5">
              <BedDouble className="h-4 w-4 text-amber-500" /> {house.bedrooms} спальни
            </span>
            <span className="flex items-center gap-1.5">
              <Bath className="h-4 w-4 text-amber-500" /> {house.bathrooms} с/у
            </span>
            <span className="flex items-center gap-1.5">
              <Clock3 className="h-4 w-4 text-amber-500" /> {house.buildMonths}
            </span>
          </div>
        </div>

        {/* Световая полоса при ховере */}
        {hover && (
          <motion.div
            layoutId={`shine-${house.id}`}
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-400 to-transparent"
          />
        )}
      </motion.div>
    </motion.div>
  );
}

const FILTERS: { key: "all" | House["tech"]; label: string }[] = [
  { key: "all", label: "Все проекты" },
  { key: "frame", label: "Каркасные" },
  { key: "gas", label: "Газобетон" },
  { key: "brick", label: "Кирпич" },
];

export default function Catalog({
  houses,
  selected,
  onSelect,
  onOpen,
}: {
  houses: House[];
  selected: "all" | House["tech"];
  onSelect: (f: "all" | House["tech"]) => void;
  onOpen: (h: House) => void;
}) {
  const filtered =
    selected === "all" ? houses : houses.filter((h) => h.tech === selected);

  return (
    <section id="catalog" className="relative py-24 md:py-32">
      {/* декоративные пятна */}
      <div className="pointer-events-none absolute left-[-10%] top-[10%] h-96 w-96 rounded-full bg-amber-500/8 blur-[130px]" />
      <div className="pointer-events-none absolute right-[-8%] bottom-[15%] h-80 w-80 rounded-full bg-amber-600/6 blur-[120px]" />

      <div className="mx-auto max-w-7xl px-4">
        <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-end">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-4 inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-4 py-1.5 text-[11px] md:text-xs font-semibold uppercase tracking-[0.25em] text-amber-400"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
              Каталог проектов
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.08 }}
              className="font-display text-3xl md:text-5xl font-bold text-stone-50"
            >
              Выберите <span className="text-amber-500">свой дом</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.14 }}
              className="mt-4 max-w-xl text-sm md:text-base text-stone-400"
            >
              8 готовых проектов с разными технологиями и ценами — от компактного
              каркасника до кирпичного особняка. Цены под ключ, с инженерией и отделкой.
            </motion.p>
          </div>

          {/* Фильтры */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex flex-wrap gap-2"
          >
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => onSelect(f.key)}
                className="relative rounded-full px-4.5 md:px-5 py-2.5 text-sm font-semibold"
              >
                {selected === f.key && (
                  <motion.span
                    layoutId="filter-pill"
                    className="absolute inset-0 rounded-full bg-amber-500"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span
                  className={`relative z-10 ${
                    selected === f.key ? "text-stone-950" : "text-stone-300 hover:text-amber-400"
                  }`}
                >
                  {f.label}
                </span>
              </button>
            ))}
          </motion.div>
        </div>

        {/* Сетка домов */}
        <motion.div layout className="mt-12 grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((h, i) => (
            <TiltCard key={h.id} house={h} index={i} onOpen={onOpen} />
          ))}
        </motion.div>

        {/* Хин про участок */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 flex flex-col md:flex-row items-center justify-between gap-5 rounded-3xl border border-stone-800 bg-card/60 p-6 md:p-8 backdrop-blur"
        >
          <p className="text-sm md:text-base text-stone-300 max-w-2xl">
            <span className="font-semibold text-amber-400">Нет участка?</span>{" "}
            Поможем подобрать землю в Минске и области: средние цены 2025 года —
            от 1 100 $ за сотку в дальних районах до 23 000 $ за сотку в ближнем
            поясе столицы.
          </p>
          <MagneticButton variant="ghost" onClick={() => scrollToId("#prices")}>
            Смотреть цены рынка
          </MagneticButton>
        </motion.div>
      </div>
    </section>
  );
}
