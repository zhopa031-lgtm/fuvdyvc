"use client";

import { motion } from "framer-motion";
import { PHONE_DISPLAY, PHONE_TEL, INSTAGRAM_URL, INSTAGRAM_HANDLE, ADDRESS } from "@/lib/houses";
import { scrollToId } from "./smooth-scroll";
import { Home, Phone, Camera, MapPin } from "lucide-react";

const NAV = [
  { label: "Каталог", id: "#catalog" },
  { label: "Цены", id: "#prices" },
  { label: "Этапы", id: "#steps" },
  { label: "О нас", id: "#about" },
  { label: "Контакты", id: "#contacts" },
];

export default function Footer() {
  return (
    <footer className="mt-auto border-t border-stone-800/80 bg-stone-950/95">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="flex flex-col items-start justify-between gap-10 md:flex-row md:items-center">
          {/* Бренд */}
          <button
            onClick={() => scrollToId("body")}
            data-cursor="hover"
            className="group text-left"
          >
            <span className="font-display text-2xl font-bold text-stone-50">
              Новый<span className="text-amber-500">Дом</span>
            </span>
            <span className="mt-1 flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-stone-500">
              <MapPin className="h-3.5 w-3.5 text-amber-500" />
              Минск · Беларусь
            </span>
          </button>

          {/* Навигация */}
          <nav className="flex flex-wrap gap-x-7 gap-y-3">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => scrollToId(n.id)}
                data-cursor="hover"
                className="text-sm font-medium text-stone-400 transition-colors hover:text-amber-400"
              >
                {n.label}
              </button>
            ))}
          </nav>

          {/* Контакты */}
          <div className="flex flex-col items-start gap-2.5">
            <a
              href={`tel:${PHONE_TEL}`}
              className="flex items-center gap-2 text-sm font-semibold text-stone-200 transition-colors hover:text-amber-400"
            >
              <Phone className="h-4 w-4 text-amber-500" /> {PHONE_DISPLAY}
            </a>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-sm font-semibold text-stone-200 transition-colors hover:text-amber-400"
            >
              <Camera className="h-4 w-4 text-amber-500" /> Instagram: {INSTAGRAM_HANDLE}
            </a>
            <span className="flex items-center gap-2 text-sm text-stone-500">
              <Home className="h-4 w-4 text-amber-500" /> {ADDRESS}
            </span>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-stone-800/80 pt-6 md:flex-row md:items-center">
          <p className="text-xs text-stone-600">
            © {new Date().getFullYear()} ООО «НовыйДом». Строительство домов под ключ
            в Минске и по всей Беларуси.
          </p>
          <p className="text-xs text-stone-600">
            Цены на сайте носят информационный характер и не являются публичной
            офертой.
          </p>
        </div>
      </div>
    </footer>
  );
}
