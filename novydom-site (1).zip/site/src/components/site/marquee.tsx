"use client";

import { motion } from "framer-motion";

const ITEMS = [
  "Каркасные дома",
  "Дома из газобетона",
  "Кирпичные коттеджи",
  "Проекты и смета",
  "Отделка под ключ",
  "Гарантия 10 лет",
  "Минск и Беларусь",
];

export default function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="relative z-10 -rotate-1 border-y border-amber-500/25 bg-amber-500 py-3.5 md:py-4 shadow-[0_10px_50px_rgba(245,158,11,0.25)]">
      <div className="flex overflow-hidden">
        <div className="animate-marquee flex shrink-0 items-center gap-8 pr-8">
          {row.map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-8 whitespace-nowrap font-display text-sm md:text-base font-semibold uppercase tracking-[0.18em] text-stone-950"
            >
              {item}
              <span className="inline-block h-2.5 w-2.5 rotate-45 bg-stone-950/80" />
            </span>
          ))}
        </div>
        <div aria-hidden className="animate-marquee flex shrink-0 items-center gap-8 pr-8">
          {row.map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-8 whitespace-nowrap font-display text-sm md:text-base font-semibold uppercase tracking-[0.18em] text-stone-950"
            >
              {item}
              <span className="inline-block h-2.5 w-2.5 rotate-45 bg-stone-950/80" />
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
