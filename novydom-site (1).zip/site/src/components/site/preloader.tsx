"use client";

import { useEffect, useRef, useState } from "react";
import { motion, animate } from "framer-motion";

export default function Preloader({ onFinish }: { onFinish: () => void }) {
  const [n, setN] = useState(0);
  const done = useRef(false);

  useEffect(() => {
    const controls = animate(0, 100, {
      duration: 2,
      ease: [0.65, 0, 0.35, 1],
      onUpdate: (v) => setN(Math.round(v)),
      onComplete: () => {
        if (!done.current) {
          done.current = true;
          setTimeout(onFinish, 350);
        }
      },
    });
    return () => controls.stop();
  }, []);

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-stone-950"
      exit={{ y: "-100%", borderBottomLeftRadius: "50% 8%", borderBottomRightRadius: "50% 8%" }}
      transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="flex flex-col items-center"
      >
        <div className="font-display text-4xl md:text-6xl font-bold tracking-tight text-stone-100">
          Новый<span className="text-amber-500">Дом</span>
        </div>
        <div className="mt-2 text-xs md:text-sm uppercase tracking-[0.4em] text-stone-500">
          Минск · Беларусь
        </div>
      </motion.div>

      <div className="mt-12 flex items-end gap-3">
        <span className="font-display text-6xl md:text-8xl font-extrabold text-amber-500 tabular-nums">
          {n}
        </span>
        <span className="mb-2 md:mb-3 font-display text-xl md:text-2xl text-stone-400">%</span>
      </div>

      <div className="mt-6 h-px w-56 md:w-72 overflow-hidden bg-stone-800">
        <motion.div
          className="h-full bg-amber-500"
          style={{ width: `${n}%` }}
          transition={{ ease: "linear" }}
        />
      </div>

      <div className="mt-4 text-[11px] uppercase tracking-[0.3em] text-stone-600">
        Строим дома вашей мечты
      </div>
    </motion.div>
  );
}
