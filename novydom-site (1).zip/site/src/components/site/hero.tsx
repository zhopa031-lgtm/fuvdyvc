"use client";

import { useRef } from "react";
import Image from "next/image";
import {
  motion,
  useScroll,
  useTransform,
  useMotionValue,
  useSpring,
} from "framer-motion";
import { MagneticButton } from "./magnetic";
import { scrollToId } from "./smooth-scroll";
import { PHONE_DISPLAY, PHONE_TEL } from "@/lib/houses";

const TITLE_LINE_1 = "Строим дома";
const TITLE_LINE_2 = "вашей мечты";

function LetterLine({
  text,
  show,
  baseDelay,
  className,
}: {
  text: string;
  show: boolean;
  baseDelay: number;
  className?: string;
}) {
  return (
    <span className={`block whitespace-nowrap ${className ?? ""}`}>
      {text.split("").map((ch, i) => (
        <span key={i} className="inline-block overflow-hidden pb-2 -mb-2 align-bottom">
          <motion.span
            className="inline-block will-change-transform"
            initial={{ y: "120%", rotate: 6, opacity: 0 }}
            animate={show ? { y: "0%", rotate: 0, opacity: 1 } : {}}
            transition={{
              duration: 0.9,
              delay: baseDelay + i * 0.035,
              ease: [0.22, 1, 0.36, 1],
            }}
          >
            {ch === " " ? "\u00A0" : ch}
          </motion.span>
        </span>
      ))}
    </span>
  );
}

export default function Hero({ loaded }: { loaded: boolean }) {
  const ref = useRef<HTMLElement>(null);

  // Параллакс при скролле
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const imgScale = useTransform(scrollYProgress, [0, 1], [1, 1.18]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "60%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  // Параллакс от мыши
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const smx = useSpring(mx, { stiffness: 60, damping: 18 });
  const smy = useSpring(my, { stiffness: 60, damping: 18 });
  const imgMX = useTransform(smx, [-1, 1], [-18, 18]);
  const imgMY = useTransform(smy, [-1, 1], [-12, 12]);
  const glowMX = useTransform(smx, [-1, 1], [40, -40]);

  const onMouseMove = (e: React.MouseEvent) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    mx.set(((e.clientX - r.left) / r.width) * 2 - 1);
    my.set(((e.clientY - r.top) / r.height) * 2 - 1);
  };

  return (
    <section
      ref={ref}
      onMouseMove={onMouseMove}
      className="relative flex min-h-[100svh] items-center justify-center overflow-hidden"
    >
      {/* Фон с параллаксом */}
      <motion.div className="absolute inset-[-4%]" style={{ y: imgY, scale: imgScale }}>
        <motion.div className="absolute inset-0" style={{ x: imgMX, y: imgMY }}>
          <Image
            src="/images/hero1.jpg"
            alt="Современный загородный дом, построенный в Минской области"
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-b from-stone-950/80 via-stone-950/55 to-stone-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_20%,rgba(12,10,9,0.75)_100%)]" />
      </motion.div>

      {/* Световое пятно, следующее за мышью */}
      <motion.div
        className="pointer-events-none absolute inset-0 z-[1]"
        style={{ x: glowMX }}
      >
        <div className="absolute left-[8%] top-[18%] h-72 w-72 rounded-full bg-amber-500/15 blur-[100px]" />
      </motion.div>

      {/* Контент */}
      <motion.div
        style={{ y: contentY, opacity: contentOpacity }}
        className="relative z-10 flex flex-col items-center px-4 pb-24 pt-28 text-center"
      >
        <motion.div
          initial={{ opacity: 0, y: -14 }}
          animate={loaded ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="mb-7 inline-flex items-center gap-3 rounded-full border border-stone-100/20 bg-stone-100/5 px-5 py-2 backdrop-blur-md"
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-500 opacity-70" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-amber-500" />
          </span>
          <span className="text-xs md:text-sm font-semibold uppercase tracking-[0.22em] text-stone-200">
            Минск · Беларусь · с 2011 года
          </span>
        </motion.div>

        <h1 className="font-display text-[9.2vw] leading-[1.06] font-bold sm:text-6xl md:text-7xl lg:text-[86px] text-stone-50">
          <LetterLine text={TITLE_LINE_1} show={loaded} baseDelay={0.35} />
          <LetterLine
            text={TITLE_LINE_2}
            show={loaded}
            baseDelay={0.65}
            className="text-amber-500"
          />
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={loaded ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.15 }}
          className="mt-6 max-w-xl text-sm md:text-lg text-stone-300"
        >
          Каркасные дома, газобетон и кирпич под ключ в Минске и по всей Беларуси.
          Фиксированная смета в договоре, гарантия 10 лет.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={loaded ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.3 }}
          className="mt-9 flex flex-col items-center gap-4 sm:flex-row"
        >
          <MagneticButton onClick={() => scrollToId("#catalog")}>
            Смотреть каталог домов
          </MagneticButton>
          <MagneticButton variant="ghost" onClick={() => scrollToId("#contacts")}>
            Бесплатная консультация
          </MagneticButton>
        </motion.div>

        <motion.a
          href={`tel:${PHONE_TEL}`}
          initial={{ opacity: 0 }}
          animate={loaded ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 1.5 }}
          className="mt-8 font-display text-lg md:text-2xl font-semibold tracking-wide text-stone-100 transition-colors hover:text-amber-400"
        >
          {PHONE_DISPLAY}
        </motion.a>
      </motion.div>

      {/* Индикатор скролла */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={loaded ? { opacity: 1 } : {}}
        transition={{ delay: 1.8, duration: 0.8 }}
        className="absolute bottom-7 left-1/2 z-10 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="flex h-12 w-7 items-start justify-center rounded-full border border-stone-100/30 p-1.5"
        >
          <div className="h-3 w-1 rounded-full bg-amber-500" />
        </motion.div>
      </motion.div>

      {/* Вертикальная надпись */}
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={loaded ? { opacity: 1, x: 0 } : {}}
        transition={{ delay: 1.6, duration: 0.8 }}
        className="absolute right-6 top-1/2 z-10 hidden -translate-y-1/2 lg:block"
      >
        <div className="font-display text-[11px] uppercase tracking-[0.5em] text-stone-400 [writing-mode:vertical-rl]">
          Каталог · Цены · Этапы · Контакты
        </div>
      </motion.div>
    </section>
  );
}
