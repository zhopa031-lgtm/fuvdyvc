"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useScroll } from "framer-motion";
import { Menu, X, Phone } from "lucide-react";
import { PHONE_DISPLAY, PHONE_TEL } from "@/lib/houses";
import { scrollToId } from "./smooth-scroll";
import { Magnetic } from "./magnetic";

const NAV = [
  { label: "Каталог", id: "#catalog" },
  { label: "Цены", id: "#prices" },
  { label: "Этапы", id: "#steps" },
  { label: "О нас", id: "#about" },
  { label: "Контакты", id: "#contacts" },
];

export default function Navbar({ loaded }: { loaded: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollY } = useScroll();

  useEffect(() => {
    return scrollY.on("change", (v) => setScrolled(v > 40));
  }, [scrollY]);

  const go = (id: string) => {
    setOpen(false);
    setTimeout(() => scrollToId(id), open ? 350 : 0);
  };

  return (
    <>
      <motion.header
        initial={{ y: -90, opacity: 0 }}
        animate={loaded ? { y: 0, opacity: 1 } : {}}
        transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed inset-x-0 top-0 z-[70] transition-all duration-500 ${
          scrolled
            ? "border-b border-stone-800/70 bg-stone-950/85 backdrop-blur-xl"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:h-[72px]">
          {/* Логотип */}
          <button
            onClick={() => go("body")}
            data-cursor="hover"
            className="font-display text-lg md:text-xl font-bold text-stone-50"
          >
            Новый<span className="text-amber-500">Дом</span>
            <span className="ml-2 hidden text-[10px] font-medium uppercase tracking-[0.3em] text-stone-500 sm:inline">
              Минск
            </span>
          </button>

          {/* Десктоп-меню */}
          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => go(n.id)}
                data-cursor="hover"
                className="group relative text-sm font-medium text-stone-300 transition-colors hover:text-amber-400"
              >
                {n.label}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-amber-500 transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Magnetic strength={0.25}>
              <a
                href={`tel:${PHONE_TEL}`}
                className="hidden items-center gap-2 rounded-full bg-amber-500 px-5 py-2.5 text-sm font-bold text-stone-950 transition-colors hover:bg-amber-400 md:flex"
              >
                <Phone className="h-4 w-4" />
                {PHONE_DISPLAY}
              </a>
            </Magnetic>

            {/* Бургер */}
            <button
              onClick={() => setOpen(!open)}
              aria-label={open ? "Закрыть меню" : "Открыть меню"}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-stone-700 text-stone-200 transition-colors hover:border-amber-500 hover:text-amber-400 lg:hidden"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Мобильное меню */}
      <motion.div
        initial={false}
        animate={open ? "show" : "hide"}
        variants={{
          show: { clipPath: "inset(0% 0% 0% 0%)", transition: { duration: 0.5, ease: [0.76, 0, 0.24, 1] } },
          hide: { clipPath: "inset(0% 0% 100% 0%)", transition: { duration: 0.45, ease: [0.76, 0, 0.24, 1] } },
        }}
        className="fixed inset-0 z-[65] flex flex-col items-center justify-center gap-2 bg-stone-950/97 backdrop-blur-2xl lg:hidden"
      >
        {NAV.map((n, i) => (
          <motion.button
            key={n.id}
            onClick={() => go(n.id)}
            initial={{ opacity: 0, y: 30 }}
            animate={open ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ delay: 0.15 + i * 0.07, duration: 0.4 }}
            className="py-3 font-display text-3xl font-bold text-stone-100 transition-colors hover:text-amber-400"
          >
            {n.label}
          </motion.button>
        ))}
        <motion.a
          href={`tel:${PHONE_TEL}`}
          initial={{ opacity: 0, y: 30 }}
          animate={open ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ delay: 0.55, duration: 0.4 }}
          className="mt-8 font-display text-xl font-bold text-amber-500"
        >
          {PHONE_DISPLAY}
        </motion.a>
        <motion.span
          initial={{ opacity: 0 }}
          animate={open ? { opacity: 1 } : { opacity: 0 }}
          transition={{ delay: 0.65 }}
          className="mt-4 text-xs uppercase tracking-[0.4em] text-stone-500"
        >
          Минск · Беларусь
        </motion.span>
      </motion.div>
    </>
  );
}
