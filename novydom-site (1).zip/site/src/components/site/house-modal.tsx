"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { TECH_LABEL, type House } from "@/lib/houses";
import { MagneticButton } from "./magnetic";
import { scrollToId } from "./smooth-scroll";
import {
  Ruler,
  BedDouble,
  Bath,
  Layers,
  Clock3,
  CheckCircle2,
  Wallet,
} from "lucide-react";

export default function HouseModal({
  house,
  onClose,
}: {
  house: House | null;
  onClose: () => void;
}) {
  return (
    <Dialog open={!!house} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        data-lenis-prevent
        aria-describedby={undefined}
        className="max-h-[85svh] overflow-y-auto overscroll-contain rounded-3xl border-stone-800 bg-stone-950 p-0 sm:max-w-3xl"
      >
        {house && (
          <div className="relative">
            <div className="relative aspect-[16/9] overflow-hidden sm:rounded-t-3xl">
              <Image
                src={house.image}
                alt={`Проект ${house.name}`}
                fill
                sizes="(max-width: 768px) 100vw, 768px"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/30 to-transparent" />
              <div className="absolute bottom-4 left-6 right-6">
                <DialogTitle className="font-display text-2xl md:text-3xl font-bold text-stone-50">
                  {house.name}
                </DialogTitle>
                <p className="mt-1 text-sm text-stone-400">{house.district}</p>
              </div>
            </div>

            <div className="p-6 md:p-8">
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-amber-400">
                  {TECH_LABEL[house.tech]}
                </span>
                {house.priceFrom >= 200000 && (
                  <span className="rounded-full bg-amber-500 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-stone-950">
                    Премиум
                  </span>
                )}
              </div>

              <p className="mt-5 text-sm md:text-base leading-relaxed text-stone-300">
                {house.tagline}
              </p>

              {/* Характеристики */}
              <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
                {[
                  { icon: Ruler, label: "Площадь", value: `${house.area} м²` },
                  { icon: Layers, label: "Этажей", value: house.floors },
                  { icon: BedDouble, label: "Спален", value: house.bedrooms },
                  { icon: Bath, label: "Санузлов", value: house.bathrooms },
                  { icon: Clock3, label: "Срок стройки", value: house.buildMonths },
                  {
                    icon: Wallet,
                    label: "Цена под ключ",
                    value: `от ${house.priceFrom.toLocaleString("ru-RU")} $`,
                  },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="rounded-2xl border border-stone-800 bg-card/70 p-3.5"
                  >
                    <s.icon className="h-4.5 w-4.5 text-amber-500" />
                    <div className="mt-2 text-xs text-stone-500">{s.label}</div>
                    <div className="mt-0.5 text-sm md:text-base font-bold text-stone-100">
                      {s.value}
                    </div>
                  </div>
                ))}
              </div>

              {/* Что входит */}
              <div className="mt-7">
                <h4 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-stone-400">
                  Что входит в цену
                </h4>
                <ul className="mt-4 space-y-2.5">
                  {house.included.map((item, i) => (
                    <motion.li
                      key={item}
                      initial={{ opacity: 0, x: -14 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + i * 0.07 }}
                      className="flex items-start gap-2.5 text-sm md:text-[15px] text-stone-300"
                    >
                      <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-amber-500" />
                      {item}
                    </motion.li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 flex flex-col sm:flex-row items-center gap-4">
                <MagneticButton onClick={() => { onClose(); setTimeout(() => scrollToId("#contacts"), 150); }}>
                  Хочу такой дом
                </MagneticButton>
                <p className="text-xs text-stone-500">
                  Точная смета — после бесплатной консультации на участке
                </p>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
