"use client";

import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { RevealTitle, SectionBadge, FadeIn } from "./reveal";

const STEPS = [
  {
    num: "01",
    title: "Консультация и участок",
    time: "1–3 дня",
    text: "Встречаемся в Минске или на вашем участке, слушаем пожелания, подбираем проект под бюджет. Консультация бесплатная.",
  },
  {
    num: "02",
    title: "Проект и смета",
    time: "2–4 недели",
    text: "Архитектурный проект, рабочие чертежи и детальная смета. Цена фиксируется в договоре и больше не меняется.",
  },
  {
    num: "03",
    title: "Фундамент",
    time: "2–4 недели",
    text: "Геодезия, земляные работы, заливка плиты или ленты с утеплением. Каждый этап принимает ваш личный инженер.",
  },
  {
    num: "04",
    title: "Коробка и кровля",
    time: "2–3 месяца",
    text: "Стены, перекрытия, кровля, окна. Дом закрывается контур — можно смело зимовать без ущерба для стройки.",
  },
  {
    num: "05",
    title: "Инженерия и отделка",
    time: "2–4 месяца",
    text: "Электрика, водоснабжение, канализация, вентиляция, тёплые полы, чистовая отделка по дизайн-проекту.",
  },
  {
    num: "06",
    title: "Ключи и гарантия",
    time: "финал",
    text: "Передаём дом с гарантийным талоном на 10 лет, инструкциями по системам и бесплатным сервисным осмотром через год.",
  },
];

export default function Process() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.72", "end 0.85"],
  });
  const lineScale = useSpring(scrollYProgress, { stiffness: 90, damping: 24 });

  return (
    <section id="steps" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="flex justify-center">
            <SectionBadge>Как мы работаем</SectionBadge>
          </div>
          <RevealTitle
            text="От мечты до новоселья — 6 шагов"
            className="mt-5 font-display text-3xl md:text-5xl font-bold text-stone-50"
          />
        </div>

        <div ref={ref} className="relative mt-16 md:mt-20">
          {/* Прогресс-линия */}
          <div className="absolute left-6 top-0 h-full w-px bg-stone-800 md:left-1/2" />
          <motion.div
            style={{ scaleY: lineScale }}
            className="absolute left-6 top-0 h-full w-px origin-top bg-gradient-to-b from-amber-500 via-amber-400 to-amber-600 md:left-1/2"
          />

          <div className="space-y-14 md:space-y-20">
            {STEPS.map((s, i) => {
              const left = i % 2 === 0;
              return (
                <div
                  key={s.num}
                  className={`relative flex md:w-1/2 ${
                    left ? "md:pr-14" : "md:ml-auto md:pl-14"
                  } pl-16 md:pl-0 ${!left ? "md:pl-14" : ""}`}
                >
                  {/* Точка */}
                  <motion.span
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ type: "spring", stiffness: 300, damping: 18 }}
                    className={`absolute top-1 flex h-12 w-12 items-center justify-center rounded-full border-2 border-amber-500 bg-stone-950 font-display text-sm font-bold text-amber-500 shadow-[0_0_24px_rgba(245,158,11,0.35)] ${
                      left
                        ? "left-0 md:-right-6 md:left-auto"
                        : "left-0 md:-left-6"
                    }`}
                  >
                    {s.num}
                  </motion.span>

                  <motion.div
                    initial={{ opacity: 0, y: 36, x: left ? -24 : 24 }}
                    whileInView={{ opacity: 1, y: 0, x: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
                    whileHover={{ scale: 1.02 }}
                    className="w-full rounded-3xl border border-stone-800 bg-card/70 p-6 md:p-7 backdrop-blur transition-colors hover:border-amber-500/40"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="font-display text-lg md:text-xl font-bold text-stone-50">
                        {s.title}
                      </h3>
                      <span className="shrink-0 rounded-full bg-amber-500/12 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-amber-400">
                        {s.time}
                      </span>
                    </div>
                    <p className="mt-3 text-sm md:text-[15px] leading-relaxed text-stone-400">
                      {s.text}
                    </p>
                  </motion.div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
