"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ClipReveal, FadeIn, RevealTitle, SectionBadge } from "./reveal";
import { ShieldCheck, FileSignature, Users, Wrench } from "lucide-react";

const FEATURES = [
  {
    icon: FileSignature,
    title: "Договор с фикс-сметой",
    text: "Цена в договоре не растёт в процессе. Никаких «внезапно понадобилось ещё на 20 000 $».",
  },
  {
    icon: ShieldCheck,
    title: "Гарантия 10 лет",
    text: "На конструктив и все работы. Сервисный осмотр дома через год — бесплатно.",
  },
  {
    icon: Users,
    title: "Своя бригада",
    text: "Без субподряда: инженер и мастера в штате. Фото- и видеоотчёты о стройке каждую неделю.",
  },
  {
    icon: Wrench,
    title: "Инженерия в комплекте",
    text: "Электрика, вода, канализация, вентиляция и тёплые полы входят в цену под ключ.",
  },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 lg:grid-cols-2">
        {/* Фотографии */}
        <div className="relative">
          <ClipReveal className="relative aspect-[4/5] overflow-hidden rounded-3xl border border-stone-800 shadow-2xl">
            <Image
              src="/images/about1.jpg"
              alt="Современный коттедж, построенный компанией в Беларуси"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </ClipReveal>
          <motion.div
            initial={{ opacity: 0, scale: 0.85, rotate: -6 }}
            whileInView={{ opacity: 1, scale: 1, rotate: -3 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="absolute -bottom-8 -right-2 w-[46%] overflow-hidden rounded-3xl border-4 border-stone-950 shadow-2xl md:-right-6"
          >
            <div className="relative aspect-[3/4]">
              <Image
                src="/images/about2.jpg"
                alt="Фрагмент архитектуры дома"
                fill
                sizes="40vw"
                className="object-cover"
              />
            </div>
          </motion.div>
          {/* Опыт */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="absolute -left-3 top-8 rounded-2xl border border-amber-500/40 bg-stone-950/85 px-5 py-3.5 backdrop-blur-md md:-left-8"
          >
            <div className="font-display text-2xl font-extrabold text-amber-500">14 лет</div>
            <div className="text-xs text-stone-400">строим в Беларуси</div>
          </motion.div>
        </div>

        {/* Текст и фичи */}
        <div>
          <SectionBadge>Почему НовыйДом</SectionBadge>
          <RevealTitle
            text="Строим так, как построили бы себе"
            className="mt-5 font-display text-3xl md:text-4xl font-bold text-stone-50"
          />
          <FadeIn delay={0.1}>
            <p className="mt-5 text-sm md:text-base leading-relaxed text-stone-400">
              «НовыйДом» — минская строительная компания. С 2011 года мы построили
              327 домов в Минске, Минской области и по всей Республике Беларусь:
              от компактных каркасников в Боровой до кирпичных коттеджей у Дроздов.
              Мы не обещаем «самые низкие цены» — вместо этого показываем рыночные
              цифры, честную смету и даём 10 лет гарантии.
            </p>
          </FadeIn>

          <div className="mt-9 grid grid-cols-1 gap-4 sm:grid-cols-2">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                whileHover={{ y: -6 }}
                className="rounded-3xl border border-stone-800 bg-card/60 p-5 transition-colors hover:border-amber-500/40"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/12 text-amber-500">
                  <f.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-3.5 font-display text-sm md:text-base font-bold text-stone-100">
                  {f.title}
                </h3>
                <p className="mt-2 text-xs md:text-sm leading-relaxed text-stone-400">
                  {f.text}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
