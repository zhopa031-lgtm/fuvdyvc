export type Tech = "frame" | "gas" | "brick";

export interface House {
  id: string;
  name: string;
  district: string;
  tech: Tech;
  area: number;
  floors: number;
  bedrooms: number;
  bathrooms: number;
  priceFrom: number;
  buildMonths: string;
  image: string;
  tagline: string;
  included: string[];
}

export const TECH_LABEL: Record<Tech, string> = {
  frame: "Каркасная технология",
  gas: "Газобетон",
  brick: "Кирпич",
};

export const HOUSES: House[] = [
  {
    id: "raubichi",
    name: "«Раубичи»",
    district: "Минский район",
    tech: "frame",
    area: 96,
    floors: 2,
    bedrooms: 3,
    bathrooms: 2,
    priceFrom: 68900,
    buildMonths: "3–4 мес.",
    image: "/images/house-raubichi.jpg",
    tagline:
      "Компактный каркасный дом для семьи из 3–4 человек. Двускатная кровля, панорамное окно в гостиной, терраса 12 м².",
    included: [
      "Фундамент УШП и геодезия",
      "Каркас из сухой доски камерной сушки",
      "Кровля и утепление 250 мм",
      "Инженерные сети под ключ",
      "Черновая и чистовая отделка",
    ],
  },
  {
    id: "borovaya",
    name: "«Боровая»",
    district: "аг. Боровая, Минский район",
    tech: "frame",
    area: 118,
    floors: 2,
    bedrooms: 4,
    bathrooms: 2,
    priceFrom: 87500,
    buildMonths: "3–5 мес.",
    image: "/images/house-borovaya.jpg",
    tagline:
      "Классический каркасный дом с эркером и гаражом. Оптимальное соотношение площади и бюджета для постоянного проживания.",
    included: [
      "Фундамент МЗЛФ с утеплением",
      "Каркас + ОСП, ветро- и пароизоляция",
      "Кровля металлочерепица",
      "Электрика, водоснабжение, канализация",
      "Отделка под ключ по дизайн-проекту",
    ],
  },
  {
    id: "logoy",
    name: "«Логойский»",
    district: "Логойское направление",
    tech: "frame",
    area: 142,
    floors: 2,
    bedrooms: 5,
    bathrooms: 3,
    priceFrom: 104000,
    buildMonths: "4–6 мес.",
    image: "/images/house-logoy.jpg",
    tagline:
      "Просторный каркасный коттедж с вторым светом в гостиной, кабинетом и сауной. Для большой семьи и загородной жизни.",
    included: [
      "Фундамент свайно-ростверковый",
      "Каркас с усиленными перекрытиями",
      "Второй свет и панорамное остекление",
      "Вентиляция с рекуперацией",
      "Отделка под ключ + сауна",
    ],
  },
  {
    id: "uruche",
    name: "«Уручье»",
    district: "г. Минск, микрорайон Уручье",
    tech: "gas",
    area: 105,
    floors: 1,
    bedrooms: 3,
    bathrooms: 2,
    priceFrom: 98000,
    buildMonths: "5–7 мес.",
    image: "/images/house-uruche.jpg",
    tagline:
      "Одноэтажный дом из газобетона с мансардой. Каменные стены, минимальная усадка, заселяйтесь сразу после отделки.",
    included: [
      "Монолитная плита с утеплением",
      "Газобетон D400 400 мм + утеплитель",
      "Скатная кровля с мансардой",
      "Тёплый пол на первом этаже",
      "Отделка под ключ",
    ],
  },
  {
    id: "zaslavl",
    name: "«Заславль»",
    district: "г. Заславль",
    tech: "gas",
    area: 154,
    floors: 2,
    bedrooms: 4,
    bathrooms: 3,
    priceFrom: 152000,
    buildMonths: "6–8 мес.",
    image: "/images/house-zaslavl.jpg",
    tagline:
      "Двухэтажный дом из газобетона с гаражом и камином. Монолитные перекрытия, фасад с утеплением и декоративной штукатуркой.",
    included: [
      "МЗЛФ + монолитные перекрытия",
      "Газобетон 400 мм, армопояс, мауэрлат",
      "Кровля гибкая черепица",
      "Камин и дымоход",
      "Отделка под ключ + гараж",
    ],
  },
  {
    id: "krinitsa",
    name: "«Криничный»",
    district: "аг. Криничный, Минский район",
    tech: "gas",
    area: 189,
    floors: 2,
    bedrooms: 5,
    bathrooms: 3,
    priceFrom: 186000,
    buildMonths: "7–9 мес.",
    image: "/images/house-krinitsa.jpg",
    tagline:
      "Премиальный дом из газобетона с панорамными окнами, террасой 30 м² и кухней-гостиной 48 м². Максимум света и воздуха.",
    included: [
      "УШП + тёплые полы по всему дому",
      "Газобетон D400 + минвата 200 мм",
      "Панорамное остекление в пол",
      "Умный дом: свет, шторы, климат",
      "Отделка под ключ по дизайн-проекту",
    ],
  },
  {
    id: "drozdy",
    name: "«Дрозды»",
    district: "г. Минск, ул. в районе Дроздов",
    tech: "brick",
    area: 176,
    floors: 2,
    bedrooms: 4,
    bathrooms: 3,
    priceFrom: 218000,
    buildMonths: "8–10 мес.",
    image: "/images/house-drozdy.jpg",
    tagline:
      "Кирпичный коттедж бизнес-класса с бассейном и гостевым блоком. Керамический кирпич, монолитные перекрытия, цокольный этаж.",
    included: [
      "Монолитный фундамент + цокольный этаж",
      "Кирпич керамический 380 мм + утеплитель",
      "Монолитные перекрытия и лестница",
      "Бассейн 4×8 м и сауна",
      "Отделка под ключ премиум-уровня",
    ],
  },
  {
    id: "nemiga",
    name: "«Немига»",
    district: "г. Минск и пригород",
    tech: "brick",
    area: 248,
    floors: 2,
    bedrooms: 5,
    bathrooms: 4,
    priceFrom: 342000,
    buildMonths: "10–12 мес.",
    image: "/images/house-nemiga.jpg",
    tagline:
      "Флагманский кирпичный особняк: второй свет, зимний сад, мастер-этаж 70 м². Индивидуальная архитектура и инженерия.",
    included: [
      "Плитный фундамент + подземная парковка",
      "Кирпич ручной формовки 510 мм",
      "Зимний сад и панорамное остекление",
      "Системы «умный дом» и вентиляция",
      "Авторский надзор и отделка под ключ",
    ],
  },
];

/* Средние цены рынка Беларуси 2025 — по данным stroi.by, 1house.by,
   karkasservice.by, karkasnyi-dom.by, domovita.by */
export const MARKET_PRICES = [
  {
    title: "Коробка дома",
    range: "$350–480 / м²",
    note: "Фундамент, стены, кровля. По данным 1house.by для 80% клиентов.",
    accent: false,
  },
  {
    title: "Каркасный дом под ключ",
    range: "$700–950 / м²",
    note: "Реальные цифры для Минска и области: дом 120 м² — $85 000–110 000.",
    accent: true,
  },
  {
    title: "Дом из газобетона под ключ",
    range: "$900–1 100 / м²",
    note: "Каменные стены, монолитные перекрытия, заселение без усадки.",
    accent: false,
  },
  {
    title: "Кирпичный дом под ключ",
    range: "от $1 200 / м²",
    note: "Бизнес-класс: керамический кирпич, бассейны, «умный дом».",
    accent: false,
  },
];

export const EXTRA_COSTS = [
  {
    title: "Проект и документы",
    value: "1 500–5 000 BYN",
    note: "Архитектурный проект + оформление 500–1 000 BYN",
  },
  {
    title: "Участки Минск / область",
    value: "$1 100–23 000 / сотка",
    note: "Дальние районы — дешевле, ближний пояс Минска — дороже",
  },
  {
    title: "Коробка по данным stroi.by",
    value: "от 725 BYN / м²",
    note: "Под ключ — от 2 300 BYN / м²",
  },
];

export const PHONE_DISPLAY = "+375 (29) 365-77-22";
export const PHONE_TEL = "+375293657722";
export const INSTAGRAM_URL = "https://instagram.com/novydom.minsk";
export const INSTAGRAM_HANDLE = "@novydom.minsk";
export const ADDRESS = "г. Минск, пр-т Дзержинского, 104, офис 512";
